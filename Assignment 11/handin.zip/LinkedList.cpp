#include "LinkedList.h"
namespace LinkedList{
Node* LinkedList::insert(Node* pos, const std::string& value){
    std::unique_ptr<Node> new_node = std::make_unique<Node>();
    new_node->getValue() = value;
    auto temp = begin();
    auto curr = begin();
    while(temp != pos){
        curr = temp;
        temp = temp->getNext();
    }
    temp->prev = nullptr;
    curr->next = nullptr;
    new_node.get()->next = temp;
    new_node.get()->getPrev() = curr;

    
    
   return new_node.get();
}

Node* LinkedList::remove(Node* pos){
    // auto delPtr = nullptr;
    // auto temp = begin();
    // auto curr = begin();
    // while(temp != pos){
    //     curr = temp;
    //     temp = temp->getNext();
    // }
    pos->prev->next = pos->next;

}
//Done
Node* LinkedList::find(const std::string& value){
    auto temp = begin();
    while(temp != end() && temp->value != value){
        temp = temp->getNext();
    }
    return temp;
}

void LinkedList::LinkedList::remove(const std::string& value){

}

std::ostream& operator<<(std::ostream& os, const Node& node){
    os << node.getValue();
    return os;
}

std::ostream& operator<<(std::ostream& os, const LinkedList& list){
    auto temp = list.begin();
    while(temp != nullptr){
        os << temp->getValue() << "->";
        temp = temp->getNext();
    }
    return os;
}
}


