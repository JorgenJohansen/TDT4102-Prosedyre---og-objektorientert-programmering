#pragma once
#include <iostream>
#include <vector>
template<typename T>
T maximum(T lhs, T rhs);